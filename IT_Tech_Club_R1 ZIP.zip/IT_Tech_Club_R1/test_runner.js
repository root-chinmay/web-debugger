// Automated Verification Script for IT Tech Club Competition Platform

async function testAll() {
  console.log('--- STARTING PLATFORM SELF-TEST ---');

  // 1. Test Competition Status
  console.log('1. Checking competition status...');
  const res1 = await fetch('http://localhost:3000/api/competition/status');
  const statusData = await res1.json();
  console.log('   Status:', statusData.status);
  console.assert(statusData.status === 'standby', 'Should be standby initially');

  // 2. Test Admin Login
  console.log('2. Testing admin login...');
  const res2 = await fetch('http://localhost:3000/api/auth/admin-login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'admin@techclub2026' })
  });
  const adminData = await res2.json();
  console.log('   Admin Login Result:', adminData.success, adminData.name);
  console.assert(adminData.success === true, 'Admin login should succeed');

  // 3. Test Participant Login (50 students registered)
  console.log('3. Testing participant login for participant01...');
  const res3 = await fetch('http://localhost:3000/api/auth/participant-login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'participant01', password: 'itc@user01' })
  });
  const partData = await res3.json();
  console.log('   Participant Login Result:', partData.success, partData.participant.name);
  console.assert(partData.success === true, 'Participant login should succeed');
  console.assert(partData.participant.number === '01', 'Participant number should be 01');

  // 4. Test Challenges Fetching
  console.log('4. Testing challenge fetching for participant...');
  const res4 = await fetch('http://localhost:3000/api/challenges?participantId=p01');
  const challengesData = await res4.json();
  console.log('   Challenges Count:', challengesData.challenges.length);
  console.assert(challengesData.challenges.length === 15, 'Should have 15 challenges');
  console.assert(challengesData.unlockedStages.includes(1), 'Stage 1 should be unlocked');
  console.assert(!challengesData.unlockedStages.includes(2), 'Stage 2 should be locked initially');

  // 5. Test Anti-Cheat Breach Recording
  console.log('5. Testing anti-cheat breach reporting (fullscreen exit)...');
  const res5 = await fetch('http://localhost:3000/api/participant/breach', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ participantId: 'p01', type: 'FULLSCREEN_EXIT' })
  });
  const breachData = await res5.json();
  console.log('   Breach Logged:', breachData.recorded);
  console.assert(breachData.recorded === true, 'Breach should be recorded');

  // 6. Test Admin Leaderboard (Admin Only)
  console.log('6. Testing Admin Leaderboard endpoint...');
  const res6 = await fetch('http://localhost:3000/api/admin/leaderboard', {
    headers: { 'Authorization': 'admin-auth-token-valid' }
  });
  const leaderboard = await res6.json();
  console.log('   Leaderboard Participants Count:', leaderboard.length);
  console.assert(leaderboard.length === 50, 'Leaderboard should include all 50 participants');
  
  // Find p01 in leaderboard to check breach count
  const p01Record = leaderboard.find(p => p.id === 'p01');
  console.log('   Participant 01 Breaches:', p01Record.breachCount);
  console.assert(p01Record.breachCount >= 1, 'Breach count should be at least 1');

  // 7. Test Admin Participants List (Credentials)
  console.log('7. Testing Admin Participants Credentials endpoint...');
  const res7 = await fetch('http://localhost:3000/api/admin/participants', {
    headers: { 'Authorization': 'admin-auth-token-valid' }
  });
  const allParticipants = await res7.json();
  console.log('   Total Registered in System:', allParticipants.length);
  console.assert(allParticipants.length === 50, 'Should have 50 participants registered');

  // 8. Test Admin Activating Competition
  console.log('8. Testing Admin activating competition...');
  const res8 = await fetch('http://localhost:3000/api/admin/competition/toggle', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'admin-auth-token-valid'
    },
    body: JSON.stringify({ action: 'start' })
  });
  const toggleData = await res8.json();
  console.log('   Updated Contest Status:', toggleData.status);
  console.assert(toggleData.status === 'active', 'Status should be active');

  // 9. Test Participant Submitting a Solution
  console.log('9. Testing participant solution submission for Challenge e1...');
  const res9 = await fetch('http://localhost:3000/api/participant/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      participantId: 'p01',
      challengeId: 'e1',
      passed: true
    })
  });
  const submitData = await res9.json();
  console.log('   Submission Result:', submitData.success, submitData.message);
  console.assert(submitData.success === true, 'Submission should be accepted');
  console.assert(submitData.stats.score === 20, 'Score should be 20 points');

  // 10. Check Leaderboard reflect update
  const res10 = await fetch('http://localhost:3000/api/admin/leaderboard', {
    headers: { 'Authorization': 'admin-auth-token-valid' }
  });
  const updatedLeaderboard = await res10.json();
  const topRank = updatedLeaderboard[0];
  console.log(`   Rank 1: ${topRank.name} with ${topRank.score} PTS`);
  console.assert(topRank.id === 'p01', 'Participant 01 should be Rank 1');
  console.assert(topRank.score === 20, 'Score should be 20');

  // Reset contest back to clean state
  await fetch('http://localhost:3000/api/admin/competition/toggle', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'admin-auth-token-valid'
    },
    body: JSON.stringify({ action: 'reset' })
  });

  console.log('--- ALL 10 TESTS PASSED SUCCESSFULLY! ---');
}

testAll().catch(err => {
  console.error('Test failed with error:', err);
  process.exit(1);
});
