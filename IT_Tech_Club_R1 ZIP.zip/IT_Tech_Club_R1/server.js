const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Paths
const DATA_DIR = path.join(__dirname, 'data');
const PARTICIPANTS_FILE = path.join(DATA_DIR, 'participants.json');
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
const CHALLENGES_FILE = path.join(DATA_DIR, 'challenges.json');
const STATE_FILE = path.join(DATA_DIR, 'state.json');

// Helper to read JSON safely
function readJSON(filePath, fallback) {
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  return fallback;
}

// Helper to write JSON safely
function writeJSON(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

// Initialize state
let competitionState = readJSON(STATE_FILE, {
  status: 'standby', // 'standby' | 'active' | 'paused'
  startedAt: null,
  submissions: {}, // { [participantId]: { solves: [challengeId], scores: total, lastSolve: timestamp } }
  breaches: [], // [ { id, participantId, participantName, participantNumber, type, timestamp, resolved } ]
  disqualified: {} // { [participantId]: true }
});

// Load static configs
let participants = readJSON(PARTICIPANTS_FILE, []);
let adminConfig = readJSON(ADMIN_FILE, { username: 'admin', password: 'admin@techclub2026' });
let challenges = readJSON(CHALLENGES_FILE, []);

// In-memory active sockets
const connectedAdmins = new Set();
const connectedParticipants = new Map(); // socketId -> participantId

// Helper to calculate participant stats
function getParticipantStats(pId) {
  const pSub = competitionState.submissions[pId] || { solves: [], score: 0, lastSolve: null };
  const pBreaches = competitionState.breaches.filter(b => b.participantId === pId);
  const participant = participants.find(p => p.id === pId);

  // Calculate solves per stage
  let s1Count = 0;
  let s2Count = 0;
  let s3Count = 0;

  (pSub.solves || []).forEach(cId => {
    const ch = challenges.find(c => c.id === cId);
    if (ch) {
      if (ch.stage === 1) s1Count++;
      if (ch.stage === 2) s2Count++;
      if (ch.stage === 3) s3Count++;
    }
  });

  return {
    id: pId,
    number: participant ? participant.number : '??',
    name: participant ? participant.name : 'Unknown',
    regNo: participant ? participant.regNo : '',
    score: pSub.score || 0,
    solvedCount: (pSub.solves || []).length,
    solves: pSub.solves || [],
    stage1Solves: s1Count,
    stage2Solves: s2Count,
    stage3Solves: s3Count,
    stage2Unlocked: s1Count >= 5,
    stage3Unlocked: s1Count >= 5 && s2Count >= 5,
    lastSolve: pSub.lastSolve,
    breachCount: pBreaches.length,
    isDisqualified: !!competitionState.disqualified[pId]
  };
}

// Compute live leaderboard (Admin-only)
function getLeaderboard() {
  const list = participants.map(p => getParticipantStats(p.id));
  // Sort by score DESC, then earliest lastSolve ASC
  list.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (a.lastSolve && b.lastSolve) return new Date(a.lastSolve) - new Date(b.lastSolve);
    if (a.lastSolve) return -1;
    if (b.lastSolve) return 1;
    return a.number.localeCompare(b.number);
  });
  return list.map((item, idx) => ({ ...item, rank: idx + 1 }));
}

// Broadcast to Admins Only
function broadcastToAdmins(event, payload) {
  io.to('admin_room').emit(event, payload);
}

// ---------------- REST APIs ----------------

// Auth: Admin Login
app.post('/api/auth/admin-login', (req, res) => {
  const { username, password } = req.body;
  adminConfig = readJSON(ADMIN_FILE, adminConfig);
  if (username === adminConfig.username && password === adminConfig.password) {
    return res.json({
      success: true,
      token: 'admin-auth-token-valid',
      name: adminConfig.name || 'Admin'
    });
  }
  return res.status(401).json({ success: false, message: 'Invalid admin credentials' });
});

// Auth: Participant Login
app.post('/api/auth/participant-login', (req, res) => {
  const { username, password } = req.body;
  participants = readJSON(PARTICIPANTS_FILE, participants);
  const participant = participants.find(
    p => p.username.toLowerCase() === (username || '').toLowerCase() && p.password === password
  );

  if (!participant) {
    return res.status(401).json({ success: false, message: 'Invalid participant username or password' });
  }

  const stats = getParticipantStats(participant.id);
  return res.json({
    success: true,
    participant: {
      id: participant.id,
      number: participant.number,
      name: participant.name,
      username: participant.username,
      regNo: participant.regNo
    },
    stats,
    competitionStatus: competitionState.status
  });
});

// Get Competition Status
app.get('/api/competition/status', (req, res) => {
  res.json({
    status: competitionState.status,
    startedAt: competitionState.startedAt
  });
});

// Participant: Get Challenges (Stage Unlocking Enforced)
app.get('/api/challenges', (req, res) => {
  const participantId = req.query.participantId;
  challenges = readJSON(CHALLENGES_FILE, challenges);

  let unlockedStages = [1];
  let solvedIds = [];

  if (participantId) {
    const stats = getParticipantStats(participantId);
    solvedIds = stats.solves;
    if (stats.stage2Unlocked) unlockedStages.push(2);
    if (stats.stage3Unlocked) unlockedStages.push(3);
  }

  // Return challenges without leaking validation internal code if desired,
  // but include test description so UI can present requirements
  const safeChallenges = challenges.map(c => ({
    id: c.id,
    stage: c.stage,
    stageName: c.stageName,
    points: c.points,
    title: c.title,
    scenario: c.scenario,
    bugDescription: c.bugDescription,
    expectedBehavior: c.expectedBehavior,
    starterCode: c.starterCode,
    testValidator: c.testValidator, // included for client-side iframe sandboxed runner
    isLocked: !unlockedStages.includes(c.stage),
    isSolved: solvedIds.includes(c.id)
  }));

  res.json({
    challenges: safeChallenges,
    unlockedStages,
    solvedIds,
    stage1Count: safeChallenges.filter(c => c.stage === 1 && c.isSolved).length,
    stage2Count: safeChallenges.filter(c => c.stage === 2 && c.isSolved).length,
    stage3Count: safeChallenges.filter(c => c.stage === 3 && c.isSolved).length
  });
});

// Participant: Submit Solution
app.post('/api/participant/submit', (req, res) => {
  const { participantId, challengeId, passed } = req.body;

  if (competitionState.status !== 'active') {
    return res.status(400).json({ success: false, message: 'Competition is not active' });
  }

  if (competitionState.disqualified[participantId]) {
    return res.status(403).json({ success: false, message: 'You have been disqualified by the administrator' });
  }

  const participant = participants.find(p => p.id === participantId);
  const challenge = challenges.find(c => c.id === challengeId);

  if (!participant || !challenge) {
    return res.status(404).json({ success: false, message: 'Participant or challenge not found' });
  }

  // Check stage unlock eligibility
  const stats = getParticipantStats(participantId);
  if (challenge.stage === 2 && !stats.stage2Unlocked) {
    return res.status(403).json({ success: false, message: 'Stage 2 is locked. Complete Stage 1 first!' });
  }
  if (challenge.stage === 3 && !stats.stage3Unlocked) {
    return res.status(403).json({ success: false, message: 'Stage 3 is locked. Complete Stage 2 first!' });
  }

  if (!competitionState.submissions[participantId]) {
    competitionState.submissions[participantId] = { solves: [], score: 0, lastSolve: null };
  }

  const pSub = competitionState.submissions[participantId];

  if (!passed) {
    return res.json({ success: false, message: 'Automated test suite failed. Please check your fix.' });
  }

  // If already solved, don't award points twice
  if (pSub.solves.includes(challengeId)) {
    return res.json({ success: true, message: 'Already solved previously', score: pSub.score });
  }

  // Award points
  pSub.solves.push(challengeId);
  pSub.score += challenge.points;
  pSub.lastSolve = new Date().toISOString();

  writeJSON(STATE_FILE, competitionState);

  // Recalculate stats
  const updatedStats = getParticipantStats(participantId);

  // Notify Admins in Real-Time with updated Leaderboard & Activity Log
  broadcastToAdmins('leaderboard_update', getLeaderboard());
  broadcastToAdmins('activity_log', {
    type: 'SOLVE',
    participantId: participant.id,
    participantNumber: participant.number,
    participantName: participant.name,
    challengeId: challenge.id,
    challengeTitle: challenge.title,
    pointsAwarded: challenge.points,
    newTotalScore: updatedStats.score,
    timestamp: new Date().toISOString()
  });

  return res.json({
    success: true,
    message: `Challenge Solved! +${challenge.points} Points Awarded!`,
    stats: updatedStats
  });
});

// In-memory cooldown tracker to prevent spam and duplicate logs
const recentBreaches = new Map(); // participantId -> { time, type }

function recordBreach(participantId, rawType) {
  const type = rawType === 'TAB_SWITCH' ? 'TAB_SWITCH' : 'FULLSCREEN_EXIT';
  const participant = participants.find(p => p.id === participantId);
  if (!participant) return null;

  const now = Date.now();
  const last = recentBreaches.get(participantId);

  // If a breach of any kind occurred for this participant in the last 4 seconds, ignore duplicate spam
  if (last && (now - last.time < 4000)) {
    return null;
  }

  recentBreaches.set(participantId, { time: now, type });

  const breachRecord = {
    id: 'br_' + now + '_' + Math.random().toString(36).substr(2, 4),
    participantId: participant.id,
    participantNumber: participant.number,
    participantName: participant.name,
    type: type,
    timestamp: new Date().toISOString(),
    resolved: false
  };

  competitionState.breaches.unshift(breachRecord);
  if (competitionState.breaches.length > 200) competitionState.breaches.pop();
  writeJSON(STATE_FILE, competitionState);

  // Send ONE PROPER REAL-TIME ALERT to Admin
  broadcastToAdmins('anti_cheat_alert', breachRecord);
  broadcastToAdmins('breach_list_update', competitionState.breaches);
  broadcastToAdmins('leaderboard_update', getLeaderboard());

  return breachRecord;
}

// Participant: Anti-Cheat Breach Detection Alert (REST fallback)
app.post('/api/participant/breach', (req, res) => {
  const { participantId, type } = req.body;
  const record = recordBreach(participantId, type);
  res.json({ success: true, recorded: !!record });
});

// ---------------- ADMIN ONLY APIS ----------------

// Middleware for Admin check
function requireAdmin(req, res, next) {
  const token = req.headers['authorization'];
  if (token === 'admin-auth-token-valid') {
    return next();
  }
  return res.status(401).json({ success: false, message: 'Unauthorized admin access' });
}

// Admin: Toggle Competition Status (Start / Pause / Reset)
app.post('/api/admin/competition/toggle', requireAdmin, (req, res) => {
  const { action } = req.body; // 'start', 'pause', 'reset'

  if (action === 'start') {
    competitionState.status = 'active';
    if (!competitionState.startedAt) {
      competitionState.startedAt = new Date().toISOString();
    }
  } else if (action === 'pause') {
    competitionState.status = 'paused';
  } else if (action === 'reset') {
    competitionState.status = 'standby';
    competitionState.startedAt = null;
    competitionState.submissions = {};
    competitionState.breaches = [];
    competitionState.disqualified = {};
  }

  writeJSON(STATE_FILE, competitionState);

  // Broadcast state change to EVERYONE (Participants & Admins)
  io.emit('competition_state_changed', {
    status: competitionState.status,
    startedAt: competitionState.startedAt
  });

  // Also broadcast refreshed leaderboard to admins
  broadcastToAdmins('leaderboard_update', getLeaderboard());
  broadcastToAdmins('breach_list_update', competitionState.breaches);

  res.json({
    success: true,
    status: competitionState.status,
    startedAt: competitionState.startedAt
  });
});

// Admin: Get Leaderboard
app.get('/api/admin/leaderboard', requireAdmin, (req, res) => {
  res.json(getLeaderboard());
});

// Admin: Get Breaches
app.get('/api/admin/breaches', requireAdmin, (req, res) => {
  res.json(competitionState.breaches);
});

// Admin: Get All Participants with Credentials
app.get('/api/admin/participants', requireAdmin, (req, res) => {
  participants = readJSON(PARTICIPANTS_FILE, participants);
  const statsList = participants.map(p => {
    const st = getParticipantStats(p.id);
    return {
      ...p,
      score: st.score,
      solvedCount: st.solvedCount,
      breachCount: st.breachCount,
      isDisqualified: st.isDisqualified
    };
  });
  res.json(statsList);
});

// Admin: Add or Update Participant
app.post('/api/admin/participants', requireAdmin, (req, res) => {
  const { number, name, username, password, regNo } = req.body;
  participants = readJSON(PARTICIPANTS_FILE, participants);

  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Username and password required' });
  }

  const existingIdx = participants.findIndex(
    p => p.username.toLowerCase() === username.toLowerCase() || p.number === number
  );

  if (existingIdx >= 0) {
    participants[existingIdx] = {
      ...participants[existingIdx],
      number: number || participants[existingIdx].number,
      name: name || participants[existingIdx].name,
      password: password,
      regNo: regNo || participants[existingIdx].regNo
    };
  } else {
    const newId = 'p' + String(participants.length + 1).padStart(2, '0');
    participants.push({
      id: newId,
      number: number || String(participants.length + 1).padStart(2, '0'),
      name: name || `Participant ${number || participants.length + 1}`,
      username,
      password,
      regNo: regNo || `ITC-2026-${String(participants.length + 1).padStart(3, '0')}`
    });
  }

  writeJSON(PARTICIPANTS_FILE, participants);
  res.json({ success: true, participants });
});

// Admin: Disqualify or Clear Participant
app.post('/api/admin/participant/action', requireAdmin, (req, res) => {
  const { participantId, action } = req.body; // 'disqualify', 'reinstate', 'reset_score'

  if (action === 'disqualify') {
    competitionState.disqualified[participantId] = true;
    // Notify participant socket directly
    io.emit('participant_disqualified', { participantId });
  } else if (action === 'reinstate') {
    delete competitionState.disqualified[participantId];
  } else if (action === 'reset_score') {
    if (competitionState.submissions[participantId]) {
      competitionState.submissions[participantId] = { solves: [], score: 0, lastSolve: null };
    }
  }

  writeJSON(STATE_FILE, competitionState);
  broadcastToAdmins('leaderboard_update', getLeaderboard());

  res.json({ success: true, stats: getParticipantStats(participantId) });
});

// Admin: Get Challenges for editing
app.get('/api/admin/challenges', requireAdmin, (req, res) => {
  challenges = readJSON(CHALLENGES_FILE, challenges);
  res.json(challenges);
});

// Admin: Save or Update Challenge
app.post('/api/admin/challenges', requireAdmin, (req, res) => {
  const updatedChallenges = req.body;
  if (Array.isArray(updatedChallenges)) {
    challenges = updatedChallenges;
    writeJSON(CHALLENGES_FILE, challenges);
    return res.json({ success: true, count: challenges.length });
  }
  res.status(400).json({ success: false, message: 'Expected an array of challenges' });
});

// ---------------- SOCKET.IO REAL-TIME CHANNELS ----------------
io.on('connection', (socket) => {
  // Client registration
  socket.on('register_admin', (token) => {
    if (token === 'admin-auth-token-valid') {
      socket.join('admin_room');
      connectedAdmins.add(socket.id);
      // Immediately send current leaderboard & breaches to newly connected admin
      socket.emit('leaderboard_update', getLeaderboard());
      socket.emit('breach_list_update', competitionState.breaches);
      socket.emit('competition_state_changed', {
        status: competitionState.status,
        startedAt: competitionState.startedAt
      });
    }
  });

  socket.on('register_participant', (data) => {
    if (data && data.participantId) {
      connectedParticipants.set(socket.id, data.participantId);
      socket.join(`participant_${data.participantId}`);
      // Notify admins of online participant count
      broadcastToAdmins('online_participants_count', connectedParticipants.size);
    }
  });

  // Anti-cheat breach alert via WebSocket for instant delivery
  socket.on('report_breach', (data) => {
    if (data && data.participantId) {
      recordBreach(data.participantId, data.type);
    }
  });

  socket.on('disconnect', () => {
    connectedAdmins.delete(socket.id);
    if (connectedParticipants.has(socket.id)) {
      connectedParticipants.delete(socket.id);
      broadcastToAdmins('online_participants_count', connectedParticipants.size);
    }
  });
});

// Start Server
server.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`⚡ IT TECH CLUB DEBUGGING COMPETITION PLATFORM ⚡`);
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`Admin Portal:       http://localhost:${PORT}/admin.html`);
  console.log(`Participant Portal: http://localhost:${PORT}/participant.html`);
  console.log(`====================================================`);
});
