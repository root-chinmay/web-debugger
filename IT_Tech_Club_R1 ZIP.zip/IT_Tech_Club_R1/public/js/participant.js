// IT TECH CLUB PARTICIPANT CLIENT CONTROLLER

let socket = null;
let currentParticipant = null;
let competitionStatus = 'standby';
let allChallenges = [];
let activeStage = 1;
let currentChallenge = null;
let userCodeDrafts = {}; // challengeId -> code

// DOM Elements
const loginView = document.getElementById('login-view');
const standbyView = document.getElementById('standby-view');
const arenaView = document.getElementById('arena-view');
const breachOverlay = document.getElementById('fullscreen-breach-overlay');

const partLoginForm = document.getElementById('participant-login-form');
const loginError = document.getElementById('login-error');
const btnStartDebugging = document.getElementById('btn-start-debugging');
const standbyHelperText = document.getElementById('standby-helper-text');
const standbyStatusBadge = document.getElementById('standby-status-badge');

const codeEditor = document.getElementById('code-editor');
const sandboxIframe = document.getElementById('sandbox-iframe');
const testConsole = document.getElementById('test-console');
const btnRunPreview = document.getElementById('btn-run-preview');
const btnResetCode = document.getElementById('btn-reset-code');
const btnSubmitSolution = document.getElementById('btn-submit-solution');
const btnReenterFullscreen = document.getElementById('btn-reenter-fullscreen');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  initSocket();
  setupEventListeners();
  checkExistingSession();
});

// Socket.IO Setup
function initSocket() {
  socket = io();

  socket.on('connect', () => {
    if (currentParticipant) {
      socket.emit('register_participant', { participantId: currentParticipant.id });
    }
  });

  socket.on('competition_state_changed', (data) => {
    competitionStatus = data.status;
    updateCompetitionStateUI();
  });

  socket.on('participant_disqualified', (data) => {
    if (currentParticipant && data.participantId === currentParticipant.id) {
      alert('You have been disqualified by the competition administrator due to security violations.');
      logout();
    }
  });
}

// Check existing session
function checkExistingSession() {
  const saved = sessionStorage.getItem('itc_participant');
  if (saved) {
    try {
      currentParticipant = JSON.parse(saved);
      socket.emit('register_participant', { participantId: currentParticipant.id });
      checkStatusAndRoute();
    } catch (e) {
      sessionStorage.removeItem('itc_participant');
    }
  }
}

// Setup Event Listeners
function setupEventListeners() {
  // Login Form
  partLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.style.display = 'none';

    const username = document.getElementById('part-username').value.trim();
    const password = document.getElementById('part-password').value.trim();

    try {
      const res = await fetch('/api/auth/participant-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();

      if (data.success) {
        currentParticipant = data.participant;
        currentParticipant.stats = data.stats;
        sessionStorage.setItem('itc_participant', JSON.stringify(currentParticipant));

        socket.emit('register_participant', { participantId: currentParticipant.id });
        competitionStatus = data.competitionStatus;
        checkStatusAndRoute();
      } else {
        loginError.innerText = data.message || 'Login failed';
        loginError.style.display = 'block';
      }
    } catch (err) {
      loginError.innerText = 'Network connection error';
      loginError.style.display = 'block';
    }
  });

  // Start Debugging Button
  btnStartDebugging.addEventListener('click', () => {
    enterFullscreenAndStart();
  });

  // Re-enter Fullscreen Button
  btnReenterFullscreen.addEventListener('click', () => {
    requestFullscreen();
    breachOverlay.classList.remove('active');
  });

  // Code Editor Key Support (Tab indent)
  codeEditor.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = codeEditor.selectionStart;
      const end = codeEditor.selectionEnd;
      codeEditor.value = codeEditor.value.substring(0, start) + '  ' + codeEditor.value.substring(end);
      codeEditor.selectionStart = codeEditor.selectionEnd = start + 2;
    }
  });

  // Run Preview Button
  btnRunPreview.addEventListener('click', () => {
    updatePreview(codeEditor.value);
    showToast('Preview updated in sandbox', 'info');
  });

  // Reset Code Button
  btnResetCode.addEventListener('click', () => {
    if (currentChallenge) {
      if (confirm('Are you sure you want to reset to the original buggy starter code?')) {
        codeEditor.value = currentChallenge.starterCode;
        updatePreview(currentChallenge.starterCode);
        showToast('Code reset to original', 'info');
      }
    }
  });

  // Submit & Verify Button
  btnSubmitSolution.addEventListener('click', () => {
    verifyAndSubmitFix();
  });

  // Logout buttons
  document.getElementById('btn-standby-logout')?.addEventListener('click', logout);
  document.getElementById('btn-arena-logout')?.addEventListener('click', logout);

  // Fullscreen & Anti-Cheat Change Listeners
  document.addEventListener('fullscreenchange', handleFullscreenChange);
  document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
  document.addEventListener('mozfullscreenchange', handleFullscreenChange);
  document.addEventListener('MSFullscreenChange', handleFullscreenChange);

  // Tab switch listener: only triggers when tab actually switches and not already in fullscreen overlay
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && arenaView.classList.contains('active') && !breachOverlay.classList.contains('active')) {
      reportAntiCheatBreach('TAB_SWITCH');
    }
  });
}

// Route based on competition status
async function checkStatusAndRoute() {
  try {
    const res = await fetch('/api/competition/status');
    const data = await res.json();
    competitionStatus = data.status;
  } catch (e) {}

  loginView.classList.remove('active');

  // Update participant details in standby
  document.getElementById('standby-part-name').innerText = currentParticipant.name;
  document.getElementById('standby-part-number').innerText = '#' + currentParticipant.number;
  document.getElementById('standby-part-reg').innerText = currentParticipant.regNo || 'ITC-2026-000';
  document.getElementById('arena-part-label').innerText = `#${currentParticipant.number} - ${currentParticipant.name}`;

  if (competitionStatus === 'active') {
    // If already in fullscreen, go to arena; otherwise show standby with active button
    if (document.fullscreenElement) {
      standbyView.classList.remove('active');
      arenaView.classList.add('active');
      loadChallenges();
    } else {
      standbyView.classList.add('active');
      updateCompetitionStateUI();
    }
  } else {
    standbyView.classList.add('active');
    arenaView.classList.remove('active');
    updateCompetitionStateUI();
  }
}

// Update UI when Admin changes competition state
function updateCompetitionStateUI() {
  if (competitionStatus === 'active') {
    standbyStatusBadge.className = 'badge badge-green';
    standbyStatusBadge.innerHTML = '<span>●</span> Competition LIVE • Active';
    btnStartDebugging.disabled = false;
    btnStartDebugging.className = 'btn btn-green btn-lg';
    btnStartDebugging.innerHTML = '⚡ ENTER FULLSCREEN & START DEBUGGING';
    standbyHelperText.innerText = 'The competition is active! Click above to enter full screen and begin.';
  } else if (competitionStatus === 'paused') {
    standbyStatusBadge.className = 'badge badge-amber';
    standbyStatusBadge.innerHTML = '<span>●</span> Competition Paused';
    btnStartDebugging.disabled = true;
    btnStartDebugging.className = 'btn btn-cyan btn-lg';
    btnStartDebugging.innerHTML = '⏸️ Competition Paused by Admin';
    standbyHelperText.innerText = 'The host has paused the competition round.';
  } else {
    standbyStatusBadge.className = 'badge badge-amber';
    standbyStatusBadge.innerHTML = '<span>●</span> Competition Locked • Standing By';
    btnStartDebugging.disabled = true;
    btnStartDebugging.className = 'btn btn-cyan btn-lg';
    btnStartDebugging.innerHTML = '🔒 Waiting for Admin Signal...';
    standbyHelperText.innerText = 'The "Start Debugging" button will automatically activate once the host enables the competition.';
  }
}

// Enter Fullscreen and start
function enterFullscreenAndStart() {
  requestFullscreen();
  standbyView.classList.remove('active');
  arenaView.classList.add('active');
  loadChallenges();
}

function requestFullscreen() {
  const elem = document.documentElement;
  if (elem.requestFullscreen) {
    elem.requestFullscreen().catch(() => {});
  } else if (elem.webkitRequestFullscreen) {
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) {
    elem.msRequestFullscreen();
  }
}

// Anti-Cheat: Handle Fullscreen Exit
function handleFullscreenChange() {
  const isFullscreen = !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement);
  
  if (arenaView.classList.contains('active')) {
    if (!isFullscreen) {
      // User exited fullscreen during the active arena!
      breachOverlay.classList.add('active');
      reportAntiCheatBreach('FULLSCREEN_EXIT');
    } else {
      breachOverlay.classList.remove('active');
    }
  }
}

// Report Breach to Server (Debounced & Clean: One Proper Log)
let clientLastBreachTime = 0;
let clientLastBreachType = '';

function reportAntiCheatBreach(type) {
  if (!currentParticipant) return;

  const now = Date.now();
  // Don't report again if reported within last 4 seconds
  if (now - clientLastBreachTime < 4000) {
    return;
  }
  clientLastBreachTime = now;
  clientLastBreachType = type;

  // Real-time socket alert (preferred)
  if (socket && socket.connected) {
    socket.emit('report_breach', {
      participantId: currentParticipant.id,
      type: type
    });
  } else {
    // REST fallback if socket is disconnected
    fetch('/api/participant/breach', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        participantId: currentParticipant.id,
        type: type
      })
    }).catch(() => {});
  }
}

// Load Challenges
async function loadChallenges() {
  try {
    const res = await fetch(`/api/challenges?participantId=${currentParticipant.id}`);
    const data = await res.json();
    allChallenges = data.challenges || [];

    // Update Stage lock indicators
    updateStageBadges(data);

    // Switch to active stage or first available
    renderStageChallenges(activeStage);
  } catch (err) {
    showToast('Failed to load challenges', 'danger');
  }
}

// Update Stage badges
function updateStageBadges(data) {
  const s1Count = data.stage1Count || 0;
  const s2Count = data.stage2Count || 0;
  const s3Count = data.stage3Count || 0;

  document.getElementById('badge-stage-1-progress').innerText = `${s1Count}/5`;

  const tabS2 = document.getElementById('tab-stage-2');
  const badgeS2 = document.getElementById('badge-stage-2-progress');
  if (data.unlockedStages.includes(2)) {
    tabS2.classList.remove('locked');
    tabS2.querySelector('span:first-child').innerText = 'Stage 2: Medium';
    badgeS2.innerText = `${s2Count}/5`;
    badgeS2.className = 'badge badge-amber';
  } else {
    tabS2.classList.add('locked');
    tabS2.querySelector('span:first-child').innerText = '🔒 Stage 2: Medium';
    badgeS2.innerText = 'Solve 5/5 in S1';
    badgeS2.className = 'badge badge-dim';
  }

  const tabS3 = document.getElementById('tab-stage-3');
  const badgeS3 = document.getElementById('badge-stage-3-progress');
  if (data.unlockedStages.includes(3)) {
    tabS3.classList.remove('locked');
    tabS3.querySelector('span:first-child').innerText = 'Stage 3: Hard';
    badgeS3.innerText = `${s3Count}/5`;
    badgeS3.className = 'badge badge-red';
  } else {
    tabS3.classList.add('locked');
    tabS3.querySelector('span:first-child').innerText = '🔒 Stage 3: Hard';
    badgeS3.innerText = 'Solve 5/5 in S2';
    badgeS3.className = 'badge badge-dim';
  }

  // Update total score in header
  if (currentParticipant && currentParticipant.stats) {
    document.getElementById('arena-score-display').innerText = currentParticipant.stats.score;
  }
}

// Switch Stage Tab
function switchStage(stageNum) {
  const tab = document.getElementById(`tab-stage-${stageNum}`);
  if (tab.classList.contains('locked')) {
    const requiredStage = stageNum === 2 ? 'Stage 1' : 'Stage 2';
    showToast(`Stage ${stageNum} is locked! You must solve all 5 challenges in ${requiredStage} first.`, 'danger');
    return;
  }

  activeStage = stageNum;
  document.querySelectorAll('.stage-tab').forEach(t => t.classList.remove('active'));
  tab.classList.add('active');

  renderStageChallenges(activeStage);
}

// Render 5 Challenge Pills for Current Stage
function renderStageChallenges(stageNum) {
  const stageChallenges = allChallenges.filter(c => c.stage === stageNum);
  const container = document.getElementById('challenge-pills-container');
  container.innerHTML = '';

  stageChallenges.forEach((ch, idx) => {
    const pill = document.createElement('button');
    pill.className = `ch-pill ${ch.isSolved ? 'solved' : ''}`;
    pill.innerText = `P${idx + 1} ${ch.isSolved ? '✓' : ''}`;
    pill.onclick = () => selectChallenge(ch, pill);
    container.appendChild(pill);
  });

  // Select first challenge in this stage
  if (stageChallenges.length > 0) {
    const firstPill = container.children[0];
    selectChallenge(stageChallenges[0], firstPill);
  }
}

// Select a Challenge
function selectChallenge(ch, pillElement) {
  currentChallenge = ch;

  // Highlight pill
  document.querySelectorAll('.ch-pill').forEach(p => p.classList.remove('active'));
  if (pillElement) pillElement.classList.add('active');

  // Populate Problem Details
  document.getElementById('ch-stage-badge').innerText = `Stage ${ch.stage} • ${ch.stageName}`;
  document.getElementById('ch-points-badge').innerText = `+${ch.points} PTS`;
  document.getElementById('ch-title').innerText = ch.title;
  document.getElementById('ch-scenario').innerText = ch.scenario;
  document.getElementById('ch-bug').innerText = ch.bugDescription;
  document.getElementById('ch-expected').innerText = ch.expectedBehavior;

  const solvedNotice = document.getElementById('ch-solved-notice');
  if (ch.isSolved) {
    solvedNotice.style.display = 'block';
  } else {
    solvedNotice.style.display = 'none';
  }

  // Load code draft or starter code
  const codeToLoad = userCodeDrafts[ch.id] || ch.starterCode;
  codeEditor.value = codeToLoad;
  updatePreview(codeToLoad);

  // Clear test console
  testConsole.innerHTML = `
    <div class="test-status-line" style="color: var(--text-dim);">
      <span>&gt;</span> Loaded "${ch.title}". Fix the bugs and click "Verify & Submit Fix".
    </div>
  `;
}

// Update Sandbox Iframe
function updatePreview(code) {
  // Inject into iframe via srcdoc for security & isolation
  sandboxIframe.srcdoc = code;
}

// Automated Test & Verification Runner
async function verifyAndSubmitFix() {
  if (!currentChallenge) return;

  const currentCode = codeEditor.value;
  userCodeDrafts[currentChallenge.id] = currentCode;

  // Visual button state: running
  btnSubmitSolution.disabled = true;
  btnSubmitSolution.innerHTML = '⏳ Verifying Fix...';

  // Print run status in console
  testConsole.innerHTML = `
    <div class="test-status-line info">
      <span>[RUNNER]</span> Mounting fixed DOM into sandbox container...
    </div>
  `;

  try {
    // Reload iframe and wait for it to load
    await new Promise((resolve) => {
      let resolved = false;
      const onLoaded = () => {
        if (!resolved) {
          resolved = true;
          sandboxIframe.removeEventListener('load', onLoaded);
          resolve();
        }
      };
      sandboxIframe.addEventListener('load', onLoaded);
      sandboxIframe.srcdoc = currentCode;
      // Fallback timer in case load event already fired
      setTimeout(onLoaded, 350);
    });

    // Wait extra 150ms for inline scripts inside iframe to execute
    await new Promise(r => setTimeout(r, 150));

    const iframeDoc = sandboxIframe.contentDocument || (sandboxIframe.contentWindow ? sandboxIframe.contentWindow.document : null);

    if (!iframeDoc) {
      throw new Error('Sandbox document is not accessible. Please ensure preview is loaded.');
    }

    testConsole.innerHTML += `
      <div class="test-status-line info">
        <span>[TEST SUITE]</span> Executing automated assertions against sandbox...
      </div>
    `;

    let testPassed = false;
    let testMessage = '';

    try {
      // Execute validator function
      const validatorFn = new Function('return ' + currentChallenge.testValidator)();
      const result = await validatorFn(iframeDoc);

      if (result && result.pass) {
        testPassed = true;
        testMessage = result.message || 'All test assertions passed!';
        testConsole.innerHTML += `
          <div class="test-status-line pass">
            <span>✓ [PASS]</span> ${testMessage}
          </div>
        `;
      } else {
        testPassed = false;
        testMessage = result ? result.message : 'Test failed';
        testConsole.innerHTML += `
          <div class="test-status-line fail">
            <span>✗ [FAIL]</span> ${testMessage}
          </div>
        `;
      }
    } catch (err) {
      testPassed = false;
      testMessage = 'Runtime Error in validator: ' + err.message;
      testConsole.innerHTML += `
        <div class="test-status-line fail">
          <span>✗ [ERROR]</span> ${testMessage}
        </div>
      `;
    }

    // If passed, submit to backend
    if (testPassed) {
      try {
        const res = await fetch('/api/participant/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            participantId: currentParticipant.id,
            challengeId: currentChallenge.id,
            passed: true
          })
        });
        const data = await res.json();

        if (data.success) {
          currentChallenge.isSolved = true;
          currentParticipant.stats = data.stats;
          sessionStorage.setItem('itc_participant', JSON.stringify(currentParticipant));

          testConsole.innerHTML += `
            <div class="test-status-line pass" style="font-weight: bold; margin-top: 6px;">
              <span>🎉 [ACCEPTED]</span> Solution verified! +${currentChallenge.points} points awarded!
            </div>
          `;

          showToast(`Challenge Solved! +${currentChallenge.points} PTS!`, 'success');

          // Check if new stage unlocked
          if (data.stats.stage2Unlocked && activeStage === 1) {
            showToast('🔓 Stage 2 (Medium) is now UNLOCKED!', 'info');
          }
          if (data.stats.stage3Unlocked && activeStage === 2) {
            showToast('🔓 Stage 3 (Hard) is now UNLOCKED!', 'info');
          }

          // Refresh challenges state & score
          loadChallenges();
        } else {
          testConsole.innerHTML += `
            <div class="test-status-line fail">
              <span>✗ [SERVER]</span> ${data.message}
            </div>
          `;
        }
      } catch (e) {
        testConsole.innerHTML += `
          <div class="test-status-line fail">
            <span>✗ [NETWORK]</span> Failed to record submission: ${e.message}
          </div>
        `;
      }
    }
  } catch (outerErr) {
    testConsole.innerHTML += `
      <div class="test-status-line fail">
        <span>✗ [EXCEPTION]</span> ${outerErr.message}
      </div>
    `;
  } finally {
    // Always restore button state
    btnSubmitSolution.disabled = false;
    btnSubmitSolution.innerHTML = '⚡ Verify & Submit Fix';
  }
}

// Log out
function logout() {
  sessionStorage.removeItem('itc_participant');
  currentParticipant = null;
  if (document.fullscreenElement) {
    document.exitFullscreen().catch(() => {});
  }
  window.location.reload();
}

// Toast System
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let icon = 'ℹ️';
  if (type === 'success') icon = '✅';
  if (type === 'danger') icon = '🚨';

  toast.innerHTML = `
    <span style="font-size: 18px;">${icon}</span>
    <div style="font-size: 13.5px; color: #fff;">${message}</div>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}
