// IT TECH CLUB ADMIN DASHBOARD CONTROLLER

let socket = null;
let adminToken = sessionStorage.getItem('itc_admin_token') || null;
let competitionState = { status: 'standby', startedAt: null };
let currentLeaderboard = [];
let currentBreaches = [];
let currentParticipants = [];
let currentChallenges = [];
let audioAlertEnabled = true;

// Web Audio API Alarm Synthesizer
let audioCtx = null;
function playAlarmChime() {
  if (!audioAlertEnabled) return;
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!audioCtx) audioCtx = new AudioContext();
    if (audioCtx.state === 'suspended') audioCtx.resume();

    // Two-tone cyber alert
    const now = audioCtx.currentTime;
    
    // Tone 1
    const osc1 = audioCtx.createOscillator();
    const gain1 = audioCtx.createGain();
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(880, now);
    osc1.frequency.exponentialRampToValueAtTime(440, now + 0.15);
    gain1.gain.setValueAtTime(0.3, now);
    gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
    osc1.connect(gain1);
    gain1.connect(audioCtx.destination);
    osc1.start(now);
    osc1.stop(now + 0.15);

    // Tone 2
    const osc2 = audioCtx.createOscillator();
    const gain2 = audioCtx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1174, now + 0.18);
    osc2.frequency.exponentialRampToValueAtTime(587, now + 0.35);
    gain2.gain.setValueAtTime(0.35, now + 0.18);
    gain2.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
    osc2.connect(gain2);
    gain2.connect(audioCtx.destination);
    osc2.start(now + 0.18);
    osc2.stop(now + 0.35);
  } catch (e) {
    console.warn('Audio play error:', e);
  }
}

// DOM Elements
const adminLoginView = document.getElementById('admin-login-view');
const adminDashboardView = document.getElementById('admin-dashboard-view');
const adminLoginForm = document.getElementById('admin-login-form');
const adminLoginError = document.getElementById('admin-login-error');

const btnStartContest = document.getElementById('btn-start-contest');
const btnPauseContest = document.getElementById('btn-pause-contest');
const btnResetContest = document.getElementById('btn-reset-contest');
const btnAdminLogout = document.getElementById('btn-admin-logout');

const statContestBadge = document.getElementById('stat-contest-badge');
const statContestText = document.getElementById('stat-contest-text');
const statOnlineCount = document.getElementById('stat-online-count');
const statBreachCount = document.getElementById('stat-breach-count');
const statBreachBadge = document.getElementById('stat-breach-badge');
const tabBreachCounter = document.getElementById('tab-breach-counter');

const liveBreachStrip = document.getElementById('live-breach-strip');
const stripAlertTitle = document.getElementById('strip-alert-title');
const stripAlertDetail = document.getElementById('strip-alert-detail');
const btnDismissStrip = document.getElementById('btn-dismiss-strip');

const btnAudioToggle = document.getElementById('btn-audio-toggle');
const audioIcon = document.getElementById('audio-icon');
const audioStatusLabel = document.getElementById('audio-status-label');

const leaderboardTbody = document.getElementById('leaderboard-tbody');
const breachesTbody = document.getElementById('breaches-tbody');
const participantsTbody = document.getElementById('participants-tbody');
const challengesAdminList = document.getElementById('challenges-admin-list');
const leaderboardSearch = document.getElementById('leaderboard-search');

const participantModal = document.getElementById('participant-modal');
const participantForm = document.getElementById('participant-form');
const btnAddParticipantModal = document.getElementById('btn-add-participant-modal');
const btnModalCancel = document.getElementById('btn-modal-cancel');
const btnExportCsv = document.getElementById('btn-export-csv');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  setupEventListeners();
  if (adminToken === 'admin-auth-token-valid') {
    showDashboard();
  }
});

// Setup Events
function setupEventListeners() {
  // Login form
  adminLoginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    adminLoginError.style.display = 'none';

    const username = document.getElementById('admin-user').value.trim();
    const password = document.getElementById('admin-pass').value.trim();

    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();

      if (data.success) {
        adminToken = data.token;
        sessionStorage.setItem('itc_admin_token', adminToken);
        showDashboard();
      } else {
        adminLoginError.innerText = data.message || 'Invalid credentials';
        adminLoginError.style.display = 'block';
      }
    } catch (err) {
      adminLoginError.innerText = 'Network error. Check server.';
      adminLoginError.style.display = 'block';
    }
  });

  // Master Game Switches
  btnStartContest.addEventListener('click', () => toggleContest('start'));
  btnPauseContest.addEventListener('click', () => toggleContest('pause'));
  btnResetContest.addEventListener('click', () => {
    if (confirm('WARNING: Are you sure you want to RESET the competition? This will clear all contestant scores, solved problems, and security breaches.')) {
      toggleContest('reset');
    }
  });

  // Audio Toggle
  btnAudioToggle.addEventListener('click', () => {
    audioAlertEnabled = !audioAlertEnabled;
    if (audioAlertEnabled) {
      audioIcon.innerText = '🔔';
      audioStatusLabel.innerText = 'Alarm Sound: ON';
      btnAudioToggle.style.borderColor = 'var(--border-color)';
      playAlarmChime();
    } else {
      audioIcon.innerText = '🔕';
      audioStatusLabel.innerText = 'Alarm Sound: OFF';
      btnAudioToggle.style.borderColor = '#ef4444';
    }
  });

  // Dismiss Live Breach Banner
  btnDismissStrip.addEventListener('click', () => {
    liveBreachStrip.style.display = 'none';
  });

  // Logout
  btnAdminLogout.addEventListener('click', () => {
    sessionStorage.removeItem('itc_admin_token');
    window.location.reload();
  });

  // Search Filter
  leaderboardSearch.addEventListener('input', (e) => {
    renderLeaderboard(e.target.value.toLowerCase());
  });

  // Participant Modal
  btnAddParticipantModal.addEventListener('click', () => {
    document.getElementById('modal-part-title').innerText = 'Add New Contestant';
    participantForm.reset();
    participantModal.classList.add('active');
  });

  btnModalCancel.addEventListener('click', () => {
    participantModal.classList.remove('active');
  });

  participantForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      number: document.getElementById('modal-part-num').value.trim(),
      name: document.getElementById('modal-part-name').value.trim(),
      username: document.getElementById('modal-part-username').value.trim(),
      password: document.getElementById('modal-part-password').value.trim(),
      regNo: document.getElementById('modal-part-reg').value.trim()
    };

    try {
      const res = await fetch('/api/admin/participants', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': adminToken
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        showToast('Participant credentials saved successfully', 'success');
        participantModal.classList.remove('active');
        loadParticipants();
      }
    } catch (err) {
      showToast('Error saving participant', 'danger');
    }
  });

  // Export CSV
  btnExportCsv.addEventListener('click', exportCredentialsCsv);

  // Clear breaches
  document.getElementById('btn-clear-breaches')?.addEventListener('click', () => {
    if (confirm('Clear anti-cheat violation records?')) {
      currentBreaches = [];
      renderBreaches();
      statBreachCount.innerText = '0';
      statBreachBadge.innerText = '0 Alerts';
      tabBreachCounter.style.display = 'none';
    }
  });
}

// Show Dashboard & Init Socket
function showDashboard() {
  adminLoginView.classList.remove('active');
  adminDashboardView.classList.add('active');

  initAdminSocket();
  fetchContestStatus();
  loadLeaderboard();
  loadBreaches();
  loadParticipants();
  loadChallenges();
}

// Setup Admin Socket
function initAdminSocket() {
  socket = io();

  socket.on('connect', () => {
    socket.emit('register_admin', adminToken);
  });

  // Real-time Competition State Changes
  socket.on('competition_state_changed', (data) => {
    competitionState = data;
    updateContestStatusUI();
  });

  // Real-time Leaderboard Updates (ONLY SENT TO ADMIN!)
  socket.on('leaderboard_update', (leaderboard) => {
    currentLeaderboard = leaderboard;
    renderLeaderboard(leaderboardSearch.value.toLowerCase());
  });

  // Real-time Anti-Cheat Breach Alert
  socket.on('anti_cheat_alert', (breach) => {
    handleIncomingBreachAlert(breach);
  });

  // Real-time Breach List Update
  socket.on('breach_list_update', (breaches) => {
    currentBreaches = breaches;
    renderBreaches();
  });

  // Real-time Online Count
  socket.on('online_participants_count', (count) => {
    statOnlineCount.innerText = count;
  });

  // Real-time Activity Log (Solves)
  socket.on('activity_log', (log) => {
    if (log.type === 'SOLVE') {
      showToast(`🏆 Participant #${log.participantNumber} (${log.participantName}) solved "${log.challengeTitle}" (+${log.pointsAwarded} PTS)!`, 'success');
    }
  });
}

// Master Toggle
async function toggleContest(action) {
  try {
    const res = await fetch('/api/admin/competition/toggle', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': adminToken
      },
      body: JSON.stringify({ action })
    });
    const data = await res.json();
    if (data.success) {
      competitionState.status = data.status;
      updateContestStatusUI();
      showToast(`Competition status changed to: ${data.status.toUpperCase()}`, 'info');
      if (action === 'reset') {
        loadLeaderboard();
        loadBreaches();
      }
    }
  } catch (err) {
    showToast('Failed to toggle competition', 'danger');
  }
}

// Fetch Status
async function fetchContestStatus() {
  try {
    const res = await fetch('/api/competition/status');
    const data = await res.json();
    competitionState = data;
    updateContestStatusUI();
  } catch (e) {}
}

function updateContestStatusUI() {
  if (competitionState.status === 'active') {
    statContestBadge.className = 'badge badge-green';
    statContestBadge.innerHTML = '<span>●</span> ACTIVE';
    statContestText.innerText = 'Competition Live';
    statContestText.style.color = 'var(--accent-emerald)';

    btnStartContest.disabled = true;
    btnPauseContest.disabled = false;
  } else if (competitionState.status === 'paused') {
    statContestBadge.className = 'badge badge-cyan';
    statContestBadge.innerHTML = '<span>●</span> PAUSED';
    statContestText.innerText = 'Contest Paused';
    statContestText.style.color = 'var(--accent-cyan)';

    btnStartContest.disabled = false;
    btnPauseContest.disabled = true;
  } else {
    statContestBadge.className = 'badge badge-amber';
    statContestBadge.innerHTML = '<span>●</span> STANDBY';
    statContestText.innerText = 'Awaiting Start';
    statContestText.style.color = 'var(--accent-amber)';

    btnStartContest.disabled = false;
    btnPauseContest.disabled = true;
  }
}

// Incoming Breach Alert Handler (Clean single alert display)
function handleIncomingBreachAlert(breach) {
  // Play Web Audio Sound
  playAlarmChime();

  // Show Red Warning Strip
  liveBreachStrip.style.display = 'flex';
  const timeFormatted = new Date(breach.timestamp).toLocaleTimeString();
  
  let violationLabel = 'FULLSCREEN EXITED';
  if (breach.type === 'TAB_SWITCH') violationLabel = 'TAB SWITCHED';

  stripAlertTitle.innerHTML = `🚨 SECURITY ALERT: ${violationLabel}!`;
  stripAlertDetail.innerHTML = `Participant #${breach.participantNumber} (<strong>${breach.participantName}</strong>) triggered <strong>${violationLabel}</strong> at <strong>${timeFormatted}</strong>.`;

  // Show only 1 toast at a time for clean alert feed
  showToast(`🚨 Security Alert: Participant #${breach.participantNumber} ${breach.participantName} - ${violationLabel}`, 'danger');

  // Update counters & tables
  loadBreaches();
}

// Load Leaderboard
async function loadLeaderboard() {
  try {
    const res = await fetch('/api/admin/leaderboard', {
      headers: { 'Authorization': adminToken }
    });
    currentLeaderboard = await res.json();
    renderLeaderboard(leaderboardSearch.value.toLowerCase());
  } catch (e) {}
}

function renderLeaderboard(filterQuery = '') {
  leaderboardTbody.innerHTML = '';

  const filtered = currentLeaderboard.filter(p => 
    p.name.toLowerCase().includes(filterQuery) ||
    p.number.toLowerCase().includes(filterQuery) ||
    p.regNo.toLowerCase().includes(filterQuery)
  );

  if (filtered.length === 0) {
    leaderboardTbody.innerHTML = `
      <tr>
        <td colspan="10" style="text-align: center; color: var(--text-dim); padding: 30px;">
          No contestants match the query.
        </td>
      </tr>
    `;
    return;
  }

  filtered.forEach(p => {
    const tr = document.createElement('tr');
    if (p.isDisqualified) {
      tr.style.opacity = '0.5';
      tr.style.textDecoration = 'line-through';
    }

    // Rank Medal
    let rankBadgeClass = 'rank-other';
    if (p.rank === 1) rankBadgeClass = 'rank-1';
    if (p.rank === 2) rankBadgeClass = 'rank-2';
    if (p.rank === 3) rankBadgeClass = 'rank-3';

    // Solve time
    const timeDisplay = p.lastSolve 
      ? new Date(p.lastSolve).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      : '--';

    tr.innerHTML = `
      <td><span class="rank-badge ${rankBadgeClass}">${p.rank}</span></td>
      <td>
        <strong>${p.name}</strong>
        <span class="badge badge-dim" style="margin-left: 6px;">#${p.number}</span>
      </td>
      <td style="font-family: var(--font-mono); color: var(--text-dim);">${p.regNo || '--'}</td>
      <td style="text-align: center;">
        <span class="badge ${p.stage1Solves === 5 ? 'badge-green' : 'badge-dim'}">${p.stage1Solves}/5</span>
      </td>
      <td style="text-align: center;">
        <span class="badge ${p.stage2Solves === 5 ? 'badge-green' : (p.stage2Unlocked ? 'badge-amber' : 'badge-dim')}">
          ${p.stage2Unlocked ? `${p.stage2Solves}/5` : '🔒'}
        </span>
      </td>
      <td style="text-align: center;">
        <span class="badge ${p.stage3Solves === 5 ? 'badge-green' : (p.stage3Unlocked ? 'badge-red' : 'badge-dim')}">
          ${p.stage3Unlocked ? `${p.stage3Solves}/5` : '🔒'}
        </span>
      </td>
      <td style="text-align: center; font-weight: 700;">
        ${p.solvedCount}/15
      </td>
      <td style="text-align: right; font-weight: 800; font-family: var(--font-mono); color: var(--accent-cyan); font-size: 15px;">
        ${p.score} PTS
      </td>
      <td style="text-align: center;">
        ${p.breachCount > 0 
          ? `<span class="badge badge-red" style="font-weight: 800;">${p.breachCount}</span>` 
          : `<span style="color: var(--text-dim); font-size: 12px;">0</span>`
        }
      </td>
      <td style="text-align: right; font-family: var(--font-mono); font-size: 12px; color: var(--text-muted);">
        ${timeDisplay}
      </td>
    `;

    leaderboardTbody.appendChild(tr);
  });
}

// Load Breaches
async function loadBreaches() {
  try {
    const res = await fetch('/api/admin/breaches', {
      headers: { 'Authorization': adminToken }
    });
    currentBreaches = await res.json();
    renderBreaches();
  } catch (e) {}
}

function renderBreaches() {
  breachesTbody.innerHTML = '';
  statBreachCount.innerText = currentBreaches.length;
  statBreachBadge.innerText = `${currentBreaches.length} Alerts`;

  if (currentBreaches.length > 0) {
    tabBreachCounter.innerText = currentBreaches.length;
    tabBreachCounter.style.display = 'inline-block';
  } else {
    tabBreachCounter.style.display = 'none';
  }

  if (currentBreaches.length === 0) {
    breachesTbody.innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; color: var(--text-dim); padding: 30px;">
          ✓ No anti-cheat violations recorded. Contestants are complying with full-screen policy.
        </td>
      </tr>
    `;
    return;
  }

  currentBreaches.forEach(b => {
    const tr = document.createElement('tr');
    const timeStr = new Date(b.timestamp).toLocaleTimeString();

    let typeBadge = '<span class="badge badge-red">Fullscreen Exited</span>';
    if (b.type === 'TAB_SWITCH') typeBadge = '<span class="badge badge-amber">Tab Switch</span>';
    if (b.type === 'WINDOW_BLUR') typeBadge = '<span class="badge badge-dim">Window Unfocused</span>';

    tr.innerHTML = `
      <td style="font-family: var(--font-mono); font-size: 12px;">${timeStr}</td>
      <td><span class="badge badge-cyan">#${b.participantNumber}</span></td>
      <td><strong>${b.participantName}</strong></td>
      <td>${typeBadge}</td>
      <td><span style="color: var(--accent-red); font-size: 12px; font-weight: 600;">Recorded</span></td>
      <td style="text-align: right;">
        <button class="btn btn-secondary btn-sm" onclick="sendProctorAction('${b.participantId}', 'warn')">⚠️ Warn</button>
        <button class="btn btn-red btn-sm" onclick="sendProctorAction('${b.participantId}', 'disqualify')">⛔ Disqualify</button>
      </td>
    `;
    breachesTbody.appendChild(tr);
  });
}

// Proctor Action
async function sendProctorAction(participantId, action) {
  if (action === 'disqualify') {
    if (!confirm('Are you sure you want to DISQUALIFY this contestant?')) return;
  }
  try {
    const res = await fetch('/api/admin/participant/action', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': adminToken
      },
      body: JSON.stringify({ participantId, action })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`Action "${action.toUpperCase()}" applied to participant`, 'info');
      loadLeaderboard();
      loadParticipants();
    }
  } catch (e) {
    showToast('Failed to apply action', 'danger');
  }
}

// Load 50 Participants
async function loadParticipants() {
  try {
    const res = await fetch('/api/admin/participants', {
      headers: { 'Authorization': adminToken }
    });
    currentParticipants = await res.json();
    renderParticipants();
    document.getElementById('stat-registered-count').innerText = currentParticipants.length;
  } catch (e) {}
}

function renderParticipants() {
  participantsTbody.innerHTML = '';

  currentParticipants.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="font-family: var(--font-mono); font-weight: 700;">#${p.number}</td>
      <td><strong>${p.name}</strong></td>
      <td style="font-family: var(--font-mono); color: var(--accent-cyan);">${p.username}</td>
      <td style="font-family: var(--font-mono); color: var(--text-muted);">${p.password}</td>
      <td style="font-family: var(--font-mono); color: var(--text-dim);">${p.regNo || '--'}</td>
      <td style="font-weight: 700;">${p.score || 0} PTS</td>
      <td>
        ${p.isDisqualified 
          ? '<span class="badge badge-red">Disqualified</span>' 
          : '<span class="badge badge-green">Active</span>'
        }
      </td>
      <td style="text-align: right;">
        <button class="btn btn-secondary btn-sm" onclick="openEditParticipantModal('${p.id}')">✏️ Edit</button>
      </td>
    `;
    participantsTbody.appendChild(tr);
  });
}

function openEditParticipantModal(pId) {
  const p = currentParticipants.find(x => x.id === pId);
  if (!p) return;

  document.getElementById('modal-part-title').innerText = `Edit Participant #${p.number}`;
  document.getElementById('modal-part-num').value = p.number;
  document.getElementById('modal-part-name').value = p.name;
  document.getElementById('modal-part-username').value = p.username;
  document.getElementById('modal-part-password').value = p.password;
  document.getElementById('modal-part-reg').value = p.regNo || '';

  participantModal.classList.add('active');
}

// Export CSV of all 50 credentials
function exportCredentialsCsv() {
  let csv = 'Participant Number,Full Name,Username,Password,Registration ID,Score\n';
  currentParticipants.forEach(p => {
    csv += `"${p.number}","${p.name}","${p.username}","${p.password}","${p.regNo || ''}","${p.score || 0}"\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `IT_Tech_Club_Participant_Credentials_${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// Load 15 Challenges
async function loadChallenges() {
  try {
    const res = await fetch('/api/admin/challenges', {
      headers: { 'Authorization': adminToken }
    });
    currentChallenges = await res.json();
    renderChallengesList();
  } catch (e) {}
}

function escapeHtml(text) {
  if (!text) return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function renderChallengesList() {
  challengesAdminList.innerHTML = '';

  currentChallenges.forEach((c, idx) => {
    let stageColor = 'cyan';
    if (c.stage === 2) stageColor = 'amber';
    if (c.stage === 3) stageColor = 'red';

    const div = document.createElement('div');
    div.style.background = '#111827';
    div.style.border = '1px solid var(--border-color)';
    div.style.borderRadius = 'var(--radius-md)';
    div.style.padding = '20px 22px';

    const solutionHtml = c.solutionCode ? `
      <details style="margin-top: 14px; background: rgba(16, 185, 129, 0.06); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: var(--radius-sm); padding: 12px 14px;">
        <summary style="font-weight: 700; color: var(--accent-emerald); cursor: pointer; user-select: none; display: flex; align-items: center; justify-content: space-between;">
          <span>✅ View Correct Solution Code (Answer Key - Admin Only)</span>
          <span style="font-size: 11px; text-transform: uppercase; background: rgba(16, 185, 129, 0.2); padding: 2px 8px; border-radius: 4px;">Click to Reveal</span>
        </summary>
        <div style="margin-top: 10px; position: relative;">
          <div style="display: flex; justify-content: flex-end; margin-bottom: 6px;">
            <button class="btn btn-secondary btn-sm" onclick="copySolutionCode('${c.id}')" id="copy-btn-${c.id}">
              📋 Copy Solution Code
            </button>
          </div>
          <pre style="background: #080d16; border: 1px solid #1e293b; border-radius: 6px; padding: 14px; overflow-x: auto; font-family: var(--font-mono); font-size: 12.5px; line-height: 1.5; color: #a7f3d0;"><code id="sol-code-${c.id}">${escapeHtml(c.solutionCode)}</code></pre>
        </div>
      </details>
    ` : '';

    div.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; flex-wrap: wrap; gap: 8px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span class="badge badge-${stageColor}">Stage ${c.stage} • ${c.stageName}</span>
          <strong style="font-size: 17px; color: #fff;">#${idx + 1}: ${c.title}</strong>
        </div>
        <span class="badge badge-green">+${c.points} PTS</span>
      </div>
      <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 8px;"><strong>Scenario:</strong> ${c.scenario}</p>
      <div style="color: #fca5a5; font-size: 13.5px; margin-bottom: 6px;"><strong>Bug Description:</strong> ${c.bugDescription}</div>
      <div style="color: #6ee7b7; font-size: 13.5px;"><strong>Expected Behavior:</strong> ${c.expectedBehavior}</div>
      ${solutionHtml}
    `;

    challengesAdminList.appendChild(div);
  });
}

function copySolutionCode(challengeId) {
  const codeEl = document.getElementById(`sol-code-${challengeId}`);
  if (!codeEl) return;
  const rawText = codeEl.innerText;
  navigator.clipboard.writeText(rawText).then(() => {
    const btn = document.getElementById(`copy-btn-${challengeId}`);
    if (btn) {
      btn.innerText = '✓ Copied!';
      setTimeout(() => btn.innerText = '📋 Copy Solution Code', 2000);
    }
    showToast('Solution code copied to clipboard!', 'success');
  }).catch(() => {
    showToast('Failed to copy code to clipboard', 'danger');
  });
}

// Admin Tab Switching
function switchAdminTab(tabKey) {
  document.querySelectorAll('.admin-tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.admin-tab-content').forEach(content => content.style.display = 'none');

  document.getElementById(`tab-btn-${tabKey}`).classList.add('active');
  document.getElementById(`tab-content-${tabKey}`).style.display = 'block';

  if (tabKey === 'leaderboard') loadLeaderboard();
  if (tabKey === 'security') loadBreaches();
  if (tabKey === 'participants') loadParticipants();
  if (tabKey === 'challenges') loadChallenges();
}

// Toast Notification with Stack Capping (max 2 toasts so it never spams)
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  // Cap to max 2 toasts on screen
  while (container.children.length >= 2) {
    container.removeChild(container.firstChild);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let icon = 'ℹ️';
  if (type === 'success') icon = '✅';
  if (type === 'danger') icon = '🚨';

  toast.innerHTML = `
    <span style="font-size: 18px;">${icon}</span>
    <div style="font-size: 13.5px; color: #fff;">${message}</div>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
