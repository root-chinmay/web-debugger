# ⚡ IT Tech Club - Web Debugging Championship Platform 2026

A modern, developer-grade competitive web debugging and CTF platform designed for 50 contestants with real-time proctoring, stage-locked progression, live sandbox previews, and an admin-exclusive real-time leaderboard.

---

## 🚀 Quick Start

### 1. Prerequisites
- **Node.js**: v18+ (tested on Node v24.12.0)
- **NPM**: v9+

### 2. Start the Server
```bash
npm start
```
The application will launch on `http://localhost:3000`.

- **Main Landing Portal**: `http://localhost:3000/`
- **Participant Debugging Arena**: `http://localhost:3000/participant.html`
- **Admin Command Center**: `http://localhost:3000/admin.html`

---

## 🔑 Default Credentials

### Administrator
- **Username**: `admin`
- **Password**: `admin@techclub2026`
- **Config file**: `data/admin.json`

### 50 Pre-Registered Contestants
The platform comes pre-configured with 50 participant accounts in `data/participants.json`.
- **Username Pattern**: `participant01` to `participant50`
- **Password Pattern**: `itc@user01` to `itc@user50`
- **Registration ID Pattern**: `ITC-2026-001` to `ITC-2026-050`
- *Note*: Admin can also edit, reset passwords, add contestants, and export all credentials as a printable CSV sheet directly from the Admin Dashboard.

---

## 🎯 Architecture & Features

### 1. Real-Time Admin Master Switch
- **Standby Gate**: When participants log in before the competition starts, they are held in a high-tech **Standby Waiting Arena**. The "Start Debugging" button remains locked and disabled.
- **Instant Unlock**: When the Admin clicks **`▶ START COMPETITION`**, Socket.IO broadcasts the signal and immediately unlocks the **"Enter Fullscreen & Start Debugging"** button for all 50 contestants without requiring a page refresh.
- Admins can also **Pause** or **Reset** the competition at any time.

### 2. 🛡️ Strict Anti-Cheat & Proctoring Engine
- **Fullscreen Enforcement**: Contestants must debug in full-screen mode.
- **Instant Breach Telemetry**: If a contestant attempts to exit fullscreen (`fullscreenchange`) or switches tabs / unfocuses the window (`visibilitychange`, `blur`):
  1. An instant telemetry alert is sent to the Admin dashboard via WebSockets.
  2. The Admin dashboard plays a two-tone **synthesized cyber audio alarm** (Web Audio API) and displays a flashing red alert banner with the **Participant Number**, **Name**, **Violation Type**, and **Timestamp**.
  3. The breach is permanently logged in the Admin's Proctoring Audit Table with breach counters.
  4. The participant's screen is locked with a full-viewport red warning overlay until they click to return to full-screen.
- **Proctor Actions**: Admins can issue warnings or disqualify contestants with one click.

### 3. 🧩 3 Stages of Broken Websites (15 Problems, 600 Max Points)
- **Stage 1 (Easy)**: 5 Broken Web Problems @ **20 pts each** (100 pts total)
  - *E1*: Broken Dark Theme Switcher (Selector & class typos)
  - *E2*: Broken Live Counter App (String concatenation & NaN bugs)
  - *E3*: Broken Contact Form Validation (Missing preventDefault & inverted regex check)
  - *E4*: Broken Mobile Navigation Drawer (Element query ID mismatch & state class)
  - *E5*: Broken Discount Code Calculator (String subtraction NaN bug & validation)
- **Stage 2 (Medium)**: 5 Broken Web Problems @ **40 pts each** (200 pts total)
  - *M1*: Broken Filterable Task Manager (Array mutation splice bug & state sync)
  - *M2*: Broken Product Image Carousel (Index out-of-bounds & slide wrap-around)
  - *M3*: Broken Real-Time Search & Highlight (Case-sensitive strict matching bug)
  - *M4*: Broken Shopping Cart Total & Quantity (Item duplicate grouping & price math)
  - *M5*: Broken Accessible Modal Dialog (Event delegation, backdrop click & Escape key)
- **Stage 3 (Hard)**: 5 Broken Web Problems @ **60 pts each** (300 pts total)
  - *H1*: Broken Sortable & Paginated Table (Alphabetical numeric sorting & pagination off-by-one)
  - *H2*: Broken Multi-Step Form Wizard (Input state loss across steps & object rendering)
  - *H3*: Broken Drag & Drop Kanban Board (Missing dragover preventDefault & DOM placement)
  - *H4*: Broken Markdown Parser Live Previewer (Greedy regex backtracking & tag leakage)
  - *H5*: Broken Timed Quiz Engine (Racing interval leaks & score percentage formula)

### 4. 🔒 Stage Progression Lock
- **Stage 1** is unlocked by default.
- **Stage 2 (Medium)** unlocks only after solving **all 5 problems in Stage 1**.
- **Stage 3 (Hard)** unlocks only after solving **all 5 problems in Stage 2**.
- Attempting to switch to locked stages triggers a clear progress requirement badge (e.g. `Solve 5/5 in S1`).

### 5. 🚫 Zero Hints Policy
- As strictly requested, **no hints** are provided in any challenge or interface component.
- Contestants are given realistic problem scenarios, bug descriptions, and expected behaviors.

### 6. 🏆 Private Live Leaderboard (Admin Only)
- **Admin Exclusive**: The leaderboard is **only visible on the Admin screen** (`/admin.html`). Contestants have zero access to other participants' ranks or scores.
- **Instant WebSocket Updates**: As soon as any contestant squashes a bug, the automated DOM validator runs, awards points, and streams the updated ranking, stage breakdown, and solve timestamps to the Admin table.
- **Rank Medals**: Gold, Silver, and Bronze badges for the top 3 contestants, with search and filtering by student name or roll number.

---

## 🛠️ Customizing or Adding Questions

All 15 challenges are cleanly defined in:
`data/challenges.json`

Each challenge structure:
```json
{
  "id": "e1",
  "stage": 1,
  "stageName": "Easy",
  "points": 20,
  "title": "Broken Dark Theme Switcher",
  "scenario": "A website's dark mode toggle is failing in production...",
  "bugDescription": "The toggle button event listener targets the wrong element ID...",
  "expectedBehavior": "Clicking '#theme-toggle' should toggle the class 'dark-mode'...",
  "starterCode": "<!DOCTYPE html><html>...</html>",
  "testValidator": "async function(doc) { ... return { pass: true, message: '...' }; }"
}
```
You can edit existing questions, adjust points, or add new challenges directly in `data/challenges.json` or inspect them under the **🛠️ Challenges & Question Space** tab on the Admin dashboard.

---

## 📂 Project Structure

```
IT_Tech_Club_R1/
├── data/
│   ├── admin.json              # Superadmin credentials
│   ├── challenges.json         # 15 debugging problems with sandbox validators
│   ├── participants.json       # 50 pre-registered student credentials
│   └── state.json              # Server contest state, submissions & breaches
├── public/
│   ├── css/
│   │   └── style.css           # Cyber-dark design system & glassmorphism
│   ├── js/
│   │   ├── admin.js            # Admin controller, audio alarms & live leaderboard
│   │   └── participant.js      # Participant controller, sandbox iframe & anti-cheat
│   ├── admin.html              # Admin Command Center portal
│   ├── index.html              # Main landing page
│   └── participant.html        # Contestant arena with split editor & preview
├── package.json
├── server.js                   # Express + Socket.IO real-time server
└── test_runner.js              # Automated system test suite
```
